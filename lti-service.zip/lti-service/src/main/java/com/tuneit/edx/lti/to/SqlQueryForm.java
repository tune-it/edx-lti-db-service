package com.tuneit.edx.lti.to;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SqlQueryForm {

    private String textQuery;

}
