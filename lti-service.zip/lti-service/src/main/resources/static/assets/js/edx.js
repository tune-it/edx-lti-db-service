
var app = angular.module('BlankApp', ['ngAria', 'ngAnimate', 'ngMaterial']);

app.controller('MenuController', function() {});

